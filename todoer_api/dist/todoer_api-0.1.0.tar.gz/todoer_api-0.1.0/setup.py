# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['todoer_api']

package_data = \
{'': ['*']}

install_requires = \
['fastapi>=0.70.0,<0.71.0',
 'gunicorn>=20.1.0,<21.0.0',
 'uvicorn[standard]>=0.15.0,<0.16.0']

setup_kwargs = {
    'name': 'todoer-api',
    'version': '0.1.0',
    'description': '',
    'long_description': None,
    'author': 'Todd Cooper',
    'author_email': 'todd.coops@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'install_requires': install_requires,
    'python_requires': '>=3.9,<4.0',
}


setup(**setup_kwargs)
